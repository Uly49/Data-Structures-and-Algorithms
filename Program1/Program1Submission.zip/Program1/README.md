Ulysses Palomar \
2/7/2023 \
University of Wisconsin - Parkside \
CSCI 340 - Data Structures and Algorithms \
Professor Vijayalakshmi (Viji) Ramasamy \
Homework - Program 1